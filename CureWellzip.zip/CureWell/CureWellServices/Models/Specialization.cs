﻿using System;
using System.Linq;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace CureWellServices.Models
{
    public class Specialization
    {
        public string SpecializationCode { get; set; }
        public string SpecializationName { get; set; }
    }
}
