export interface Doctor {
  doctorId: number;
  doctorName: string;
}
