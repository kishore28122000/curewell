export interface DoctorSpecialization {
  doctorId: number;
  specializationCode: string;
  specializationDate: Date;
}
