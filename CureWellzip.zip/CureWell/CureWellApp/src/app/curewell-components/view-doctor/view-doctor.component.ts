import { Component, OnInit, DoCheck } from '@angular/core';
import { Doctor } from '../../curewell-interfaces/doctor';
import { CurewellService } from '../../curewell-services/curewell.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Route } from '@angular/compiler/src/core';

@Component({
  selector: 'app-view-doctor',
  templateUrl: './view-doctor.component.html',
})
export class ViewDoctorComponent implements OnInit {

  doctorList: Doctor[];
  showMsgDiv: boolean = false;
  doctorId: number;
  errorMsg: string;
  status: boolean;

  constructor(private _curewellService: CurewellService, private router: Router) { }

  ngOnInit() {
    //To do implement necessary logic
    this.getDoctor();


  }

  getDoctor() {
    //To do implement necessary logic
    this._curewellService.getDoctors().subscribe(
      responseProductData => {
        this.doctorList = responseProductData;
        this.showMsgDiv = false;
      },
      responseProductError => {
        this.doctorList = null;
        this.errorMsg = responseProductError;
        console.log(this.errorMsg);
      },
      () => console.log("Doctors Fetched successfully")
    );
  }


  editDoctorDetails(doctor: Doctor) {
    this.router.navigate(['/editDoctorDetails', doctor.doctorId, doctor.doctorName]);
  }
  

  removeDoctor(doctor: Doctor) {
    //To do implement necessary logic
    this._curewellService.deleteDoctor(doctor).subscribe(
      responseRemoveCartProductStatus => {
        this.status = responseRemoveCartProductStatus;
        if (this.status) {
          alert("Doctor details deleted successfully.");
          this.ngOnInit();
        }
        else {
          alert("Doctor name not deleted");
        }
      },
      responseRemoveCartProductError => {
        this.errorMsg = responseRemoveCartProductError;
        alert("Some Error Occured");
      },
      () => console.log("Remove method executed successfully")
    );
  }

  }


